from django.db import models
# Create your models here.

class Login(models.Model):
    username=models.CharField(max_length=50)
    password=models.CharField(max_length=50)
    type=models.CharField(max_length=50)
    
    def __str__(self):
        return self.username

class Source(models.Model):
    LeadSource=models.CharField(max_length=100)
     
    def __str__(self):
        return self.LeadSource   
class Purpose(models.Model):
    LeadPurpose=models.CharField(max_length=100)
     
    def __str__(self):
        return self.LeadPurpose      
    
class Status(models.Model):
    LeadStatus=models.CharField(max_length=100)
    color=models.CharField(max_length=100,null=True)
     
    def __str__(self):
        return self.LeadStatus          


    

class AdminRegister(models.Model):
    Lid=models.ForeignKey(Login,on_delete=models.CASCADE)
    Name=models.CharField(max_length=100)
    Image=models.ImageField(upload_to="images/",null=True)
    EmailId=models.CharField(max_length=50)
    PhoneNumber=models.CharField(max_length=50)
    Place=models.CharField(max_length=100,null=True)
    City=models.CharField(max_length=100,null=True)
    State=models.CharField(max_length=100,null=True)
    Country=models.CharField(max_length=100,null=True) 
    created_at = models.DateTimeField(auto_now_add=True, null=True)
    # otp=models.CharField(max_length=6,null=True)
        
    def __str__(self):
        return self.Name  
class Company(models.Model):
    CompanyName=models.CharField(max_length=100)
    Location=models.CharField(max_length=100)
    Country=models.CharField(max_length=100)  
    PhoneNumber = models.CharField(max_length=12)
    EmailId = models.EmailField(max_length=200, blank=True)
    Website = models.CharField(max_length=200, blank=True)
    Admin=models.ForeignKey(AdminRegister,on_delete=models.CASCADE)  
    
    def __str__(self):
        return self.CompanyName    
class Staff(models.Model):  
    admin=models.ForeignKey(AdminRegister,on_delete=models.CASCADE)   
    Lid=models.ForeignKey(Login,on_delete=models.CASCADE)
    Name=models.CharField(max_length=100)
    Image=models.ImageField(upload_to="images/",null=True)
    EmailId=models.CharField(max_length=50)
    PhoneNumber=models.CharField(max_length=50)
    Role=models.CharField(max_length=100)
    Place=models.CharField(max_length=100,null=True)
    City=models.CharField(max_length=100,null=True)
    State=models.CharField(max_length=100, null=True)
    Country=models.CharField(max_length=100, null=True)
    Co_Admin=(
        ('YES','yes'),
        ('NO','no'),
    )
    Admin=models.CharField(max_length=20,choices=Co_Admin,default='NO')
    
    def __str__(self):
        return self.Name    
class Lead(models.Model):
    admin=models.ForeignKey(AdminRegister,on_delete=models.CASCADE)  
    CustomerName=models.CharField(max_length=100)
    CompanyName=models.CharField(max_length=100,null=True)
    EmailId=models.CharField(max_length=50)
    PhoneNumber=models.CharField(max_length=50)  
    AlternativeNumber=models.CharField(max_length=50,null=True)     
    address=models.CharField(max_length=400)
    Source=models.ForeignKey(Source,on_delete=models.CASCADE)
    Purpose=models.ForeignKey(Purpose,on_delete=models.CASCADE)
    Type=models.CharField(max_length=100)
    Status=models.ForeignKey(Status,on_delete=models.CASCADE)
    Staff=models.ForeignKey(Staff,on_delete=models.CASCADE)
    Note=models.TextField(null=True)
    Followup_title = models.CharField(max_length=100)  
    Followup_date = models.DateField() 
    Followup_time = models.TimeField()
    created_at = models.DateTimeField(auto_now_add=True, null=True)
    
    def __str__(self):
        return self.CustomerName
class Callstatus(models.Model):
    CallStatus=models.CharField(max_length=100)    

    def __str__(self):
        return self.CallStatus
    
class Callreasons(models.Model):
    CallReasons=models.CharField(max_length=100)    

    def __str__(self):
        return self.CallReasons

class Meetingoutcome(models.Model):
    MeetingOutcome=models.CharField(max_length=100)    

    def _str_(self):
        return self.MeetingOutcome

class Taskcategory(models.Model):
    TaskCategory=models.CharField(max_length=100)    

    def __str__(self):
        return self.TaskCategory

class Task(models.Model):
    TaskName = models.CharField(max_length=100)
    Lead = models.ForeignKey('Lead', on_delete=models.CASCADE)
    AssignedBy = models.ForeignKey('AdminRegister', on_delete=models.CASCADE,null=True)
    AssignedTo = models.ForeignKey('Staff', on_delete=models.CASCADE)
    CallStatus = models.ForeignKey('Callstatus', on_delete=models.CASCADE,null=True)
    TaskCategory = models.ForeignKey('Taskcategory', on_delete=models.CASCADE)
    MeetingOutcome = models.ForeignKey('Meetingoutcome', on_delete=models.CASCADE,null=True)
    CallReason = models.ForeignKey('Callreasons', on_delete=models.CASCADE,null=True)
    Comment = models.TextField(null=True)
    Date = models.DateField()
    Time = models.TimeField()
    Description = models.TextField(null=True)      
    Status=models.CharField(max_length=50,null=True)   