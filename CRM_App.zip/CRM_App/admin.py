from django.contrib import admin
from .models import *

@admin.register(Login)
class LoginAdmin(admin.ModelAdmin):
    list_display = ['username', 'type','password']

@admin.register(Staff)
class StaffAdmin(admin.ModelAdmin):
    list_display = ['Name', 'EmailId', 'PhoneNumber', 'Role', 'Place', 'City', 'State', 'Country', 'Admin']

@admin.register(Source)
class SourceAdmin(admin.ModelAdmin):
    list_display = ['LeadSource']

@admin.register(Purpose)
class PurposeAdmin(admin.ModelAdmin):
    list_display = ['LeadPurpose']

@admin.register(Status)
class StatusAdmin(admin.ModelAdmin):
    list_display = ['LeadStatus', 'color']



@admin.register(Lead)
class LeadAdmin(admin.ModelAdmin):
    list_display = ['admin','CustomerName','Staff', 'CompanyName', 'EmailId', 'PhoneNumber', 'AlternativeNumber', 'address', 'Type', 'Note', 'Followup_title', 'Followup_date', 'Followup_time','Source','Purpose','Status']

@admin.register(AdminRegister)
class AdminRegisterAdmin(admin.ModelAdmin):
    list_display = ['Name', 'EmailId', 'PhoneNumber', 'Place', 'City', 'State', 'Country', 'Image']

@admin.register(Company)
class CompanyAdmin(admin.ModelAdmin):
    list_display = ['CompanyName', 'Location', 'Country', 'PhoneNumber', 'EmailId', 'Website', 'Admin']
@admin.register(Callstatus)
class CallstatusAdmin(admin.ModelAdmin):
    list_display = ('CallStatus',)

@admin.register(Callreasons)
class CallreasonsAdmin(admin.ModelAdmin):
    list_display = ('CallReasons',)

@admin.register(Meetingoutcome)
class MeetingoutcomeAdmin(admin.ModelAdmin):
    list_display = ('MeetingOutcome',)

@admin.register(Taskcategory)
class TaskcategoryAdmin(admin.ModelAdmin):
    list_display = ('TaskCategory',)

@admin.register(Task)
class TaskAdmin(admin.ModelAdmin):
    list_display = ('TaskName', 'Lead', 'AssignedBy', 'AssignedTo', 'CallStatus', 'TaskCategory', 'MeetingOutcome', 'CallReason', 'Comment', 'Date', 'Time', 'Description')    